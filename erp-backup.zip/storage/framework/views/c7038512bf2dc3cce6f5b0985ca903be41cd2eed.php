<tr>
    <td class="header">
        <a href="<?php echo e($url, false); ?>">
            <?php echo e($slot, false); ?>

        </a>
    </td>
</tr>
<?php /**PATH /home3/crowdfbr/erp.crowdafricahost.xyz/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>