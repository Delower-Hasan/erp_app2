[<?php echo e($slot, false); ?>](<?php echo e($url, false); ?>)
<?php /**PATH /home3/crowdfbr/erp.crowdafricahost.xyz/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>