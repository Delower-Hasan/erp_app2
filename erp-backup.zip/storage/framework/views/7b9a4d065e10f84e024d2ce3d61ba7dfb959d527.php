# Info

Welcome to the generated API reference.
<?php if($showPostmanCollectionButton): ?>
[Get Postman Collection](<?php echo e(url($outputPath.'/collection.json'), false); ?>)
<?php endif; ?><?php /**PATH /home3/crowdfbr/erp.crowdafricahost.xyz/vendor/mpociot/laravel-apidoc-generator/src/../resources/views//partials/info.blade.php ENDPATH**/ ?>