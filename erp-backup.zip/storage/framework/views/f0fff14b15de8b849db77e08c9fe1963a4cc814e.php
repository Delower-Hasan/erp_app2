<ul class="nav nav-pills nav-justified">
  <li role="presentation" <?php if($active == 'install'): ?> class="active" <?php endif; ?>>
    <a href="#">Instructions</a>
  </li>
  <!-- <li role="presentation" <?php if($active == 'server'): ?> class="active" <?php endif; ?>>
    <a href="#">Server Requirements</a>
  </li> -->
  <li role="presentation" <?php if($active == 'app_details'): ?> class="active" <?php endif; ?>>
    <a href="#">Application Details</a>
  </li>
  <li role="presentation" <?php if($active == 'success'): ?> class="active" <?php endif; ?>>
    <a href="#">Success</a>
  </li>
</ul>
<br/><?php /**PATH /home3/crowdfbr/erp.crowdafricahost.xyz/resources/views/install/partials/nav.blade.php ENDPATH**/ ?>