<?php echo e($slot, false); ?>

<?php /**PATH /home3/crowdfbr/erp.crowdafricahost.xyz/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>